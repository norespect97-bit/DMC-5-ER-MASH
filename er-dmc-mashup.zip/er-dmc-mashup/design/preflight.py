import json,glob
sheets={f[:-5]:json.load(open(f)) for f in glob.glob('*.json')}
ids={n:{r.get('id') for r in rows} for n,rows in sheets.items()}
empty=[];unver=[];bad=[]
for n,rows in sheets.items():
    for r in rows:
        k=r.get('id',r.get('rank'))
        for c,v in r.items():
            if v is None: empty.append(f"{n}:{k}.{c}")
        if r.get('verified') is False: unver.append(f"{n}:{k}")
refs={('characters','weapon'):'weapons',('characters','armor_set'):'armor',('characters','devil_trigger'):'devil_trigger'}
for (s,c),t in refs.items():
    for r in sheets[s]:
        if r[c] not in ids[t]: bad.append(f"{s}:{r['id']}.{c}->{r[c]}")
print("UNFILLED:",len(empty));print("\n".join(empty))
print("UNVERIFIED rows:",len(unver))
print("BROKEN REFS:",bad or "none")
print("BUILD READY:", not empty and not unver and not bad)
