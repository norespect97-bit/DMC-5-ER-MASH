# Handoff
Remaining work, in order:
1. Connect to Melty; game_info on elden-ring and devil-may-cry-5; search_mashups.
2. Find the Elden Ring install; set up universal-modder.
3. Fill the empty cells in design/*.json from the game's files; check proposed numbers in game.
4. Choose the plugin route for hit events, HUD rank and DMC5 input layout (check licenses).
5. Run `python3 design/preflight.py` until clean; build; test in the running game.
6. Generate the validated recipe and save it as `melty.json` at the repo root (not created yet).
7. Listing, credits, content license, remix choice: ask the author.
8. Real screenshot/clip; publish only after the author tests and approves.
Ask before spending money (fal.ai).
